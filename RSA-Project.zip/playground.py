n = 21721
e = 113
d = 14401

message = "If you're reading this its to late"
encrypted_message = ""
decrypted_message = ""

#encyption#
for x in message:
  numerize = ord(x)
  encrypt = pow(numerize, e, n)
  denumerize = chr(encrypt)
  encrypted_message += denumerize
  
  print encrypted_message

#decrypt#
for t in encrypted_message:
  numerize = ord(t)
  denumerize = pow(numerize, d, n)
  denumerize = chr(decrypt)
  decrypted_message += denumerize
  
  print decrypted_message