n = 21721
e = 113
d = 14401

message = ""
encrypted_message = "勋㵾使㰘冓㵾⫾冓䐚㵾㫩冓使ວ䐚冓⡄仪㰘䏍冓䨡㫩呈冓仪呈䲁⽶冓ວ冓⽶ວ㉘䖩仪⫾仪㉘㰘࣭冓㉸冓ວ使冓㦏仪ಋಋ仪䗼ఒ冓呈㵾冓使ວಊ㰘"
decrypted_message = ""

for t in encrypted_message:
  numerize = ord(t)
  denumerize = pow(numerize, d, n)
  denumerize = chr(decrypt)
  decrypted_message += denumerize
  print decrypted_message