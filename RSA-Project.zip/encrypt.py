n = 11021
e = 931
d = 14401

message = "school iz cool"
encrypted_message = ""
decrypted_message = ""

#encyption#
for x in message:
  numerize = ord(x)
  encrypt = pow(numerize, e, n)
  denumerize = unichr(encrypt)
  encrypted_message += denumerize
  
  print encrypted_message